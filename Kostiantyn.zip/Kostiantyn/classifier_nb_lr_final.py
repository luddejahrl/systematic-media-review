if not __name__ == "__main__":
    exit

import pandas as pd
import numpy as np
import json

import seaborn as sns
import matplotlib.pyplot as plt

#for text pre-processing
import re, string
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import SnowballStemmer
from nltk.corpus import wordnet
from nltk.stem import WordNetLemmatizer

# nltk.download('omw-1.4')
# nltk.download('punkt')
# nltk.download('averaged_perceptron_tagger')
# nltk.download('wordnet')

#for model-building
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import SGDClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, f1_score, accuracy_score, confusion_matrix
from sklearn.metrics import roc_curve, auc, roc_auc_score

# bag of words
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer

#for word embedding
import gensim
from gensim.models import Word2Vec #Word2Vec is mostly used for huge datasets
#import os

def classifier_lr(current_corpus: str, statistics_path: str):
    
    if not __name__ == "__main__":
        exit

    print('Executing Logistic Regression classfier...')

    df_train = pd.read_csv('./systematic_media_review_v3/source/data/training_testing/training_data.csv') 

    classified_out = current_corpus[:len(current_corpus)-5] + '_lr.xlsx'

    #final classified csv outputs:
    classified_out = current_corpus[:len(current_corpus)-5] + '_lr.xlsx'
    classified_out_hits = current_corpus[:len(current_corpus)-5] + '_lr_hits.xlsx'

    ## CLASS DISTRIBUTION
    #if dataset is balanced or not
    # .value_counts()  -> . Return a Series containing counts of unique rows in the DataFrame.
    x = df_train['target'].value_counts()
    
    #convert to lowercase and remove punctuations and characters and then strip
    def preprocess(text):
        text = text.lower() #lowercase text
        text = text.strip() #get rid of leading/trailing whitespace 
        text = re.compile('<.*?>').sub('', text) #Remove HTML tags/markups
        text = re.compile('[%s]' % re.escape(string.punctuation)).sub(' ', text)  #Replace punctuation with space. Careful since punctuation can sometime be useful
        #investigate removing?
        text = re.sub('\s+', ' ', text)  #Remove extra space and tabs
        text = re.sub(r'\[[0-9]*\]',' ',text) #[0-9] matches any digit (0 to 10000...)
        text = re.sub(r'[^\w\s]', '', str(text).lower().strip())
        text = re.sub(r'\d',' ',text) #matches any digit from 0 to 100000..., \D matches non-digits
        text = re.sub(r'\s+',' ',text) #\s matches any whitespace, \s+ matches multiple whitespace, \S matches non-whitespace 
        
        return text

    #1. STOPWORD REMOVAL
    def stopword(string):
        a= [i for i in string.split() if i not in stopwords.words('english')]
        return ' '.join(a)

    #2. STEMMING
    snow = SnowballStemmer('english')
    def stemming(string):
        a=[snow.stem(i) for i in word_tokenize(string) ]
        return " ".join(a)

    #3. LEMMATIZATION
    wl = WordNetLemmatizer()
    
    # This is a helper function to map NTLK position tags
    # Full list is available here: https://www.ling.upenn.edu/courses/Fall_2003/ling001/penn_treebank_pos.html
    def get_wordnet_pos(tag):
        if tag.startswith('J'):
            return wordnet.ADJ
        elif tag.startswith('V'):
            return wordnet.VERB
        elif tag.startswith('N'):
            return wordnet.NOUN
        elif tag.startswith('R'):
            return wordnet.ADV
        else:
            return wordnet.NOUN

    # Tokenize the sentence
    def lemmatizer(string):
        word_pos_tags = nltk.pos_tag(word_tokenize(string)) # Get position tags
        a=[wl.lemmatize(tag[0], get_wordnet_pos(tag[1])) for idx, tag in enumerate(word_pos_tags)] # Map the position tag and lemmatize the word/token
        return " ".join(a)

    #FINAL PREPROCESSING
    def finalpreprocess(string):
        return lemmatizer(stopword(preprocess(string)))

    #create clean text column
    df_train['clean_text'] = df_train['text'].apply(lambda x: finalpreprocess(x))

    # create Word2vec model
    #here words_f should be a list containing words from each document. say 1st row of the list is words from the 1st document/sentence
    #length of words_f is number of documents/sentences in your dataset
    df_train['clean_text_tok']=[nltk.word_tokenize(i) for i in df_train['clean_text']] #convert preprocessed sentence to tokenized sentence
    
    model = Word2Vec(df_train['clean_text_tok'],min_count=1)  #min_count=1 means word should be present at least across all documents,
    #if min_count=2 means if the word is present less than 2 times across all the documents then we shouldn't consider it

    X_train, X_val, y_train, y_val = train_test_split(df_train["clean_text"], df_train["target"], test_size=0.2, shuffle=True)
    
    # Convert x_train to vector since model can only run on numbers and not words- Fit and transform
    tfidf_vectorizer = TfidfVectorizer(use_idf=True)
    X_train_vectors_tfidf = tfidf_vectorizer.fit_transform(X_train) #tfidf runs on non-tokenized sentences unlike word2vec
    # Only transform x_test (not fit and transform)
    X_val_vectors_tfidf = tfidf_vectorizer.transform(X_val) #Don't fit() your TfidfVectorizer to your test data: it will 
    #change the word-indexes & weights to match test data. Rather, fit on the training data, then use the same train-data-
    #fit model on the test data, to reflect the fact you're analyzing the test data only based on what was learned without 
    #it, and the have compatible

    #FITTING THE CLASSIFICATION MODEL using Logistic Regression (tf-idf)
    #---------------------------------------------------------------------------------------
    lr_tfidf=LogisticRegression(solver = 'liblinear', C=10, penalty = 'l2')
    lr_tfidf.fit(X_train_vectors_tfidf, y_train)  #model

    #Predict y value for test dataset
    y_predict = lr_tfidf.predict(X_val_vectors_tfidf)
    y_prob = lr_tfidf.predict_proba(X_val_vectors_tfidf)[:,1]
    
    classification_report(y_val,y_predict)
    confusion_matrix(y_val, y_predict)
    
    # print('\n\nLogistic Regression (tf-idf)')
    # print(classification_report(y_val,y_predict))
    # print('Confusion Matrix: \n',confusion_matrix(y_val, y_predict))
    
    fpr, tpr, thresholds = roc_curve(y_val, y_prob)
    roc_auc = auc(fpr, tpr)
    # print('AUC:', roc_auc) 
    #---------------------------------------------------------------------------------------
    
    #Testing it on new dataset with the best model
    #reading the data
    df_test = pd.read_excel(current_corpus)
    df_test['clean_text'] = df_test['article_text'].apply(lambda x: finalpreprocess(x)) #preprocess the data
    X_test = df_test['clean_text'] 

    #FITTING THE CLASSIFICATION MODEL using Logistic Regression (tf-idf) ---> best results

    X_vector = tfidf_vectorizer.transform(X_test) # converting X_test to vector
    y_predict = lr_tfidf.predict(X_vector)        # use the trained model on X_vector
    y_prob = lr_tfidf.predict_proba(X_vector)[:,1]

    df_test['predict_lr'] = y_prob
    df_test['target_lr'] = y_predict
    print(df_test.head())

    #drop clean text
    df_test = df_test.drop('clean_text', axis=1)

    df_test.to_excel(classified_out, index=False)

    df_test_hits = df_test[df_test.target_lr != 0]

    df_test_hits.to_excel(classified_out_hits, index=False)
    
    #adding statistics
    with open(statistics_path) as json_file:
        json_decoded = json.load(json_file)
    json_decoded["classified relevant (logistic regression)"] = (len(df_test_hits))
    json_decoded["classified not relevant (logistic regression)"] = (len(df_test) - len(df_test_hits))
    with open(statistics_path, 'w') as json_file:
        json.dump(json_decoded, json_file, indent=4)
    
    print('\nArticles classified as Relevant: ' + str(len(df_test_hits)) + ' | Articles classified as Non-Relevant: ' + str(len(df_test) - len(df_test_hits)))
    
    print('\nClassification Logistic Regression DONE\n') 
    
    return(classified_out, statistics_path)

# data_in = './systematic_media_review_v3/source/data/retrieved_articles/Rwanda_16_02_2023_18_43_57_dr_sr_kc_r_sd.xlsx'

# data = './systematic_media_review_v3/source/data/statistics/stats_Rwanda_16_02_2023_18_43_57.json'

# classifier_lr(data_in, data)

