

def classifier_bert(current_corpus: str, statistics_path: str):
        
    #from article_classifier_bert_rajk import get_prediction
    import pandas as pd
    from transformers import AutoModelForSequenceClassification
    from transformers import AutoTokenizer
    from transformers import TrainingArguments, Trainer
    import torch
    import numpy as np
    import pyarrow as pa
    from datasets import Dataset
    from transformers import AutoTokenizer
    from sklearn.model_selection import train_test_split
    import pyarrow as pa
    from datasets import Dataset
    import json    

    if not __name__ == "__main__":
        exit        

    new_model = AutoModelForSequenceClassification.from_pretrained('./systematic_media_review_v3/source/data/models/model_1')
    
    #new tokenizer
    new_tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
    
    classified_out = current_corpus[:len(current_corpus)-5] + '_bert.xlsx'
    classified_out_hits = current_corpus[:len(current_corpus)-5] + '_bert_hits.xlsx'
    
    print('Executing BERT classfier... \n\nResults found in: {}'.format(classified_out))
    
    df_in = pd.read_excel(current_corpus)
    
    df_in['predict_bert'] = -1
    df_in['target_bert'] = -1
    
    df_out = df_in
    
    def get_prediction(text):
        encoding = new_tokenizer(text, return_tensors="pt", padding="max_length", truncation=True, max_length=128)

        outputs = new_model(**encoding)

        logits = outputs.logits

        sigmoid = torch.nn.Sigmoid()
        probs = sigmoid(logits.squeeze().cpu())
        probs = probs.detach().numpy()
        label = np.argmax(probs, axis=-1)

        if label == 1:
            result = [1, probs[1]]
            return result
        else:
            result = [0, probs[0]]
            return result

    for i in range(len(df_out)):
        
        print('BERT Classification progress: ' + str(i) + '/' + str(len(df_out)-1) + ' (' + str(round((i/(len(df_out)-1)) * 100, 2)) + ' %)', end='\r')    

        text = df_out.loc[i]['article_text']
        
        result = get_prediction(text)
        
        df_out.at[i,'target_bert'] = result[0]
        df_out.at[i,'predict_bert'] = result[1]
        
    df_out.to_excel(classified_out, index=False)        
    
    df_out_hits = df_out[df_out.target_bert != 0]
    
    df_out_hits.to_excel(classified_out_hits, index=False)
    
    # add statistics
    with open(statistics_path) as json_file:
        json_decoded = json.load(json_file)
    json_decoded["classified relevant (BERT)"] = (len(df_out_hits))
    json_decoded["classified not relevant (BERT)"] = (len(df_out) - len(df_out_hits))
    with open(statistics_path, 'w') as json_file:
        json.dump(json_decoded, json_file, indent=4)
        
    print('\nArticles classified as Relevant: ' + str(len(df_out)) + ' | Articles classified as Non-Relevant: ' + str(len(df_out) - len(df_out_hits)))
    
    print('\nClassification BERT DONE\n') 
    
    return (classified_out, statistics_path)

# data_in = './systematic_media_review_v3/source/data/retrieved_articles/Rwanda_16_02_2023_18_43_57_dr_sr_kc_r_sd_lr.xlsx'

# data = './systematic_media_review_v3/source/data/statistics/stats_Rwanda_16_02_2023_18_43_57.json'

# classifier_bert(data_in, data)