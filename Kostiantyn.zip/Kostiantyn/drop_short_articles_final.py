import pandas as pd
import json

#this function is supposed to remove rows that articles shorter then 100 characters
def drop_short_art(data, statistics_path, minimum_artcile_length=100):
    
    if not __name__ == "__main__":
        exit

    df = pd.read_excel(data) 
    
    oufile_path = data[:len(data)-5] + '_sd.xlsx'

    df_len_prior = len(df)

    print('\nRemoving rows were article text is shorter than ' + str(minimum_artcile_length) + ' characters... (Results found in: ' + str(oufile_path) + ')')

    #add colomn to check condition
    df['condition'] = False

    for i in range(1,len(df)-1):
        text = df.loc[i]['article_text']

        if(type(text) == 'nan'):
            print('nan')

        if (len(str(text)) <= minimum_artcile_length):
            df.at[i,'condition'] = True 
    
    df = df[df['article_text'].notna()]
    
    #drop articles were condition is true
    df = df.drop(df[df['condition'] == True].index)
    
    #remove regin_mentioned colomn
    df = df.drop('condition', axis=1)
    
    #adding statistics
    with open(statistics_path) as json_file:
        json_decoded = json.load(json_file)
    json_decoded['length after short dropped'] = (len(df))
    with open(statistics_path, 'w') as json_file:
        json.dump(json_decoded, json_file, indent=4)

    print('\nRows dropped: ' + str(df_len_prior - len(df)) + ' | Total number of articles: ' + str(len(df)))

    df.to_excel(oufile_path, index=False)

    return(oufile_path, statistics_path)
    
# data = './systematic_media_review_v3/source/data/retrieved_articles/Rwanda_16_02_2023_18_43_57_dr_sr_kc_r.xlsx'
    
# stats = './systematic_media_review_v3/source/data/statistics/stats_Rwanda_16_02_2023_18_43_57.json'

# drop_short_art(data, stats)

