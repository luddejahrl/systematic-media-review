#this function is supposed to remove articles that do not contain any of the keywords defined in the seach query

place_names = [
    "Rwanda",
    "Kidaho",
    "Muvumba",
    "Lubirizi",
    "Nyagatare",
    "Rwandan capital",
    "Rwemhasha",
    "Capital of Rwanda",
    "Mulindi",
    "Kirambo",
    "Kigali",
    "Byumba",
    "Muhanga",
    "Gatunda",
    "Gisenyi",
    "Ngarama",
    "Kibuye",
    "Rwamagana",
    "Cyangugu",
    "Cyamba",
    "Gabiro",
    "Ruhengeri",
    "Nyanza",
    "Kora",
    "Mutura",
    "Bugarama",
    "Gikongoro",
    "Nyamata",
    "Nyagatare",
    "Busogo",
    "Rubengera",
    "Ruhango",
    "Kayonza",
    "Butare",
    "Kabuga",
    "Musanze",
    "Munini",
    "Ndera",
    "Murambi",
    "Gisagara",
    "Ngororero",
    "Kabarore",
    "Kagitumba",
    "Rusumo",
    "Cyanika"
    "Gatuna",
    "Kibeho",
    "Goma",
    "Nemba",
    "Northern Province",
    "Northern District",
    "Southern Province",
    "Southern District",
    "Eastern Province", 
    "Eastern District", 
    "Western Province",
    "Western District",
    "Kagali",
    "Kinihira",
    "Gisenya",
    "Nyundo",
    "Muhura",
    "Rushashi",
    "Rutare",
    "Ngaru",
    "Mbogo",
    "Murambi",
    "Rukara",
    "Shyorongi",
    "Kiyumba",
    "Kinyinya",
    "Gikoro",
    "Runda",
    "Kicukiro",
    "Bulinga",
    "Bicumbi",
    "Butamwa",
    "Mabanza",
    "Gitarama",
    "Kigarama",
    "Birambo",
    "Bugesera",
    "Gishyita",
    "Bwakira",
    "Rukira",
    "Kibungo",
    "Rilima",
    "Rwamatamu",
    "Masango",
    "Ruhango",
    "Gashora",
    "Sake",
    "Gatagara",
    "Kirehe",
    "Bare",
    "Ngenda",
    "Kaduha",
    "Nyabisindu",
    "Rwesero",
    "Karaba",
    "Rusatira",
    "Gisakura",
    "Kamembe",
    "Karama",
    "Rwumba",
    "Kitabi",
    "Cyimbogo",
    "Karengera",
    "Nyakabuye",
    "Bugumya",
    "Ruramba",
    "Busoro",
    "Runyombyi",
    "Nzega"
    ]

def confirm_keywords(infile: str, statistics_path: str, country: str, 
    man_made_vals: list[str], natural_vals: list[str], outcomes_vals: list[str], rta_vals: list[str]): 

    if not __name__ == "__main__":
        exit

    import csv
    import pandas as pd
    import json

    #confirmation list - list of keywords, if the title does not have any of these words it is dropped
    keywords_list = man_made_vals + natural_vals + outcomes_vals + rta_vals
    keywords_list.append(country)
    
    #special case for the pilot study of Rwanda:
    # a list of strings that contain cities and districts in Rwanda to broaden 
    if country == 'Rwanda':
        keywords_list = keywords_list + place_names

    #file given to the function
    df_file = pd.read_excel(infile) 

    old_len = len(df_file)
    
    #add colomn for condition
    df_file['condition'] = False

    for i in range(1,len(df_file)-1):
        text = df_file.loc[i]['title']
        
        for keyword in keywords_list:
            if keyword in text:
                df_file.at[i,'condition'] = True 
    
    #drop rows were condition is false
    df_file = df_file.drop(df_file[df_file['condition'] == False].index)

    #remove regin_mentioned colomn
    df_file = df_file.drop('condition', axis=1)
    
    rows_removed = old_len - len(df_file)

    print('\nRows removed: ' + str(rows_removed))



    #adding statistics
    with open(statistics_path) as json_file:
        json_decoded = json.load(json_file)
    json_decoded["length after keyword confirmation"] = (len(df_file))
    with open(statistics_path, 'w') as json_file:
        json.dump(json_decoded, json_file, indent=4)
    
    #set path for new out_file that contains atleast one of the keywords
    new_out_file = infile[:len(infile)-5] + '_kc.xlsx'

    #save results after keyword confirmation to a new excel file
    df_file.to_excel(new_out_file, index=False)

    print("\nRemoving duplicates from list of API search results... (Results found in; {}".format(new_out_file))

    print('\nRemoving unvalidated articles DONE\n')
    
    return(new_out_file, statistics_path)

# csv_res = './systematic_media_review_v3/source/data/pre_processed/ddg_res_Algeria_15_02_2023_12_59_53_dr.xlsx'
# stats = './systematic_media_review_v3/source/data/statistics/stats_Algeria_15_02_2023_12_59_53.json'
# country = 'Algeria'
# man_made_vals = ["shoot", "shooting"]
# natural_vals = ["flood", "natural disaster"]
# rta_vals = ["traffic", "bus"]
# outcomes_vals = [ "dead", "injured"]

# confirm_keywords(csv_res, stats, country, man_made_vals, natural_vals, outcomes_vals, rta_vals)