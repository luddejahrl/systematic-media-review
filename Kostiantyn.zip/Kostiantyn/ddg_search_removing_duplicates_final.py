#takes in a path to a csv files containing among other urls from ddg api call that returns a excel file with url duplicates removed
def drop_duplicates_url_title(csv_path: str, statistics_path: str):
    
    if not __name__ == "__main__":
        exit
    
    import pandas as pd
    import json

    #-----------------------------------------------REMOVING DUPLICATES------------------------------------------------------------
    #convert csv to dataframe
    df_file = pd.read_csv(csv_path) 

    #move to new folder for processing
    csv_path = csv_path.replace("duckduckgo_results", "pre_processed")
    
    duplicates_removed_path = csv_path[:len(csv_path)-4] + '_dr.xlsx' # = url_list_jan25_v2_duplicates_removed.csv
    
    print("\nRemoving duplicates from list of API search results... (Results found in; {}".format(duplicates_removed_path))
    
    df_file = df_file.drop_duplicates(subset=['url'], keep='first')
    
    df_file_duplicates_removed = df_file.drop_duplicates(subset=['title'], keep='first')
    
    #number of duplicates
    total_number_of_hits_no_dupes = len(df_file.index) - len(df_file_duplicates_removed.index)

    #adding statistics
    with open(statistics_path) as json_file:
        json_decoded = json.load(json_file)
    json_decoded["length after duplicats dropped (url)"] = len(df_file_duplicates_removed.index)
    with open(statistics_path, 'w') as json_file:
        json.dump(json_decoded, json_file, indent=4)

    #save results after duplicate removal to an excel file
    df_file_duplicates_removed.to_excel(duplicates_removed_path, index=False)

    print('\Rows removed: ' + str(total_number_of_hits_no_dupes))
    print('\nRemoving duplicates DONE')

    return(duplicates_removed_path, statistics_path)
#-----------------------------------------------/REMOVING DUPLICATES-----------------------------------------------------------

# stats_path = "./systematic_media_review_v3/source/data/statistics/stats_Afghanistan_15_02_2023_12_02_11.json"

# csv_path = './systematic_media_review_v3/source/data/duckduckgo_results/ddg_res_Afghanistan_15_02_2023_12_02_11.csv'

# drop_duplicates_url(csv_path, stats_path)