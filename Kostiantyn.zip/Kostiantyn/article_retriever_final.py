#functions takes in a excel file path as in_file
def retriever(in_file: str, statistics_path: str): #list should have "title,body,date,source,url"   #infile: str, statistics_path: str
    
    if not __name__ == "__main__":
        exit
    
    import csv
    from csv import reader
    import newspaper
    from newspaper import Article
    import pandas as pd
    import json

    #read excel file path as
    df = pd.read_excel(in_file) 

    #article failed counter
    article_download_fail = 0
    df_file_in_len = len(df)

    #move to new folder for retrieved articles
    new_out_file_path = in_file.replace("pre_processed", "retrieved_articles") # ./Systematic_media_review/systematic_media_review_v3/source/data/retrieved_articles
    # and append new name to denote that it is downloaded
    retrieved_article = new_out_file_path[:len(new_out_file_path)-5] + '_r.xlsx'
    
    #add new columns to df 
    df['publish_date'] = ''
    df['article_text'] = ''
    df['condition'] = False # condition is succeded to download
    
    for i in range(1,len(df)):
    
        article = Article(df.loc[i]['url'])
    
        try:
            #download and parse html
            article.download()
            article.parse()
            
            #retrieve text and format text from the parsed html
            df.at[i,'article_text'] =  article.text
            
            df.at[i,'condition'] = True
            
            #retrieve publishdate and format it from the parsed html 
            publish_date = article.publish_date
            publish_date = publish_date.strftime("%Y") + '-' + publish_date.strftime("%m") + '-' + publish_date.strftime("%d")
            df.at[i,'publish_date'] = publish_date
                
        except:
            article_download_fail += 1
            pass
        
        #one line due to \r
        print('Progress: ' + str(i) + '/' + str(df_file_in_len-1) + ' (' + str(round((i/(df_file_in_len-1)) * 100, 2)) + ' %)' + ' | Unable to download: ' + str(article_download_fail), end='\r')    

    df = df.drop(df[df['condition'] == False].index)

    #drop temporary column
    df = df.drop('condition', axis=1)
    
    #convert df to excel file:
    df.to_excel(retrieved_article, index=False)
    
    #adding statistics
    with open(statistics_path) as json_file:
        json_decoded = json.load(json_file)
    json_decoded["failed to download"] = (article_download_fail)
    json_decoded['length after download'] = (len(df))
    with open(statistics_path, 'w') as json_file:
        json.dump(json_decoded, json_file, indent=4)

    print('\nNumber of articles downloaded: ' + str(len(df)) + ' Number of articles unable to download: ' + str(article_download_fail)) # retrieved_article_csv

    print("Retrieval DONE")
    
    return(retrieved_article, statistics_path)

# in_file = './systematic_media_review_v3/source/data/pre_processed/ddg_res_Bangladesh_15_02_2023_14_34_59_dr_kc.xlsx'
# statistics_path = './systematic_media_review_v3/source/data/statistics/stats_Bangladesh_15_02_2023_14_34_59.json'

# retriever(in_file, statistics_path)