# Run this app with `python app.py` and
# visit http://127.0.0.1:8050/ in your web browser.

from dash import Dash, html, dcc, dash_table, Input, Output, State, callback_context
from dash_svg import Svg, G, Path, Circle
#import dash_html_components as html
import plotly.express as px
import pandas as pd
import base64
from PIL import Image
from dash import dcc
import math
import plotly.graph_objects as go
from dash.dependencies import Input, Output, State
import base64
import io
import json
import dash_bootstrap_components as dbc
import csv
from distutils import config
import time
from datetime import datetime as dt
from datetime import date as dt_date # named such as to not mess with conflicting name 'date' for ddg api
import random

# smr imports
from ddg_search_final import duckduckgo_build_url_list

#pre-proccessing
from ddg_search_removing_duplicates_final import drop_duplicates_url_title
from confirming_keywords_final import confirm_keywords
from drop_unwanted_sites_final import drop_unwanted_sites
from drop_short_articles_final import drop_short_art
from drop_region_based_final import drop_region

#download
from article_retriever_final import retriever

#classifcation
from classifier_nb_lr_final import classifier_lr
from classifier_bert_final import classifier_bert

external_stylesheets=[dbc.themes.BOOTSTRAP]

app = Dash(__name__, external_stylesheets=external_stylesheets)

man_made_list = [
    'shoot','shooting','machete',
    'stab','stabbed','stabbing',
    'explosion','exploaded','detonation',
    'weapon', 'weapons', 'gun', 'guns']

natural_list = [
    'flood','floods','flooding',
    'earthquake','earthquakes','cyclone',
    'cyclones','storm','storms',
    'natural hazard', 'natural hazards', 'natural disaster', 'natural disasters'
]

rta_list = [
    'road', 'roads', 
    'traffic',
    'vehicle', 'vechicles',
    'car', 'cars', 
    'moto', 'motorcycle', 'motorcycles',
    'bus', 'buses',
    'truck', 'trucks'
    ]

outcomes_list = [
    'dead', 'deaseased', 'deadly', 'death',
    'fatal', 'fatally',
    'injury', 'injur', 'injured', 'injurys',
    'wound', 'wounds', 'wounded', 
    'truama', 'truamas', 
    'kill', 'killed', 'kills',
]

app.layout = html.Div(children=[
    html.H1(children='Thesis Project - Systematic media review', className='page-title'),
    
    html.Div(id='intro-explanation', children=[
        html.P('''
               Welcome to the Systematic media review - A novel method to assess mass-trauma epidemiology in absence of databases — A pilot-study in Rwanda.
               '''),
        html.P('''
        This project...
        '''),
        html.A(href='https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0258446', children='Based on the research by Lotta Velin, Laura Pompermaier & Tina Schmid Neset'),
    ]),
    
    html.Hr(),
    
    dbc.Tabs([
        dbc.Tab(label='Creating query', children=[
            html.H2(children='Select country', id='select-country-title', className='input-title'),

            html.P(''' 
                explanation
            ''', className='input-explanation'),

            html.Div(id='country-master-div', children=[
            dbc.Select(
            options=['Afghanistan', 
            'Aland Islands', 'Albania', 'Algeria', 'American Samoa', 'Andorra', 'Angola', 'Anguilla', 'Antarctica', 'Antigua and Barbuda', 'Argentina', 'Armenia', 'Aruba', 'Australia', 'Austria', 'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bermuda', 'Bhutan', 'Bolivia, Plurinational State of', 'Bonaire, Sint Eustatius and Saba', 'Bosnia and Herzegovina', 'Botswana', 'Bouvet Island', 'Brazil', 'British Indian Ocean Territory', 'Brunei Darussalam', 'Bulgaria', 'Burkina Faso', 'Burundi', 'Cambodia', 'Cameroon', 'Canada', 'Cape Verde', 'Cayman Islands', 'Central African Republic', 'Chad', 'Chile', 'China', 'Christmas Island', 'Cocos (Keeling) Islands', 'Colombia', 'Comoros', 'Congo', 'Congo, The Democratic Republic of the', 'Cook Islands', 'Costa Rica', "Côte d'Ivoire", 'Croatia', 'Cuba', 'Curaçao', 'Cyprus', 'Czech Republic', 'Denmark', 'Djibouti', 'Dominica', 'Dominican Republic', 'Ecuador', 'Egypt', 'El Salvador', 'Equatorial Guinea', 'Eritrea', 'Estonia', 'Ethiopia', 'Falkland Islands (Malvinas)', 'Faroe Islands', 'Fiji', 'Finland', 'France', 'French Guiana', 'French Polynesia', 'French Southern Territories', 'Gabon', 'Gambia', 'Georgia', 'Germany', 'Ghana', 'Gibraltar', 'Greece', 'Greenland', 'Grenada', 'Guadeloupe', 'Guam', 'Guatemala', 'Guernsey', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Heard Island and McDonald Islands', 'Holy See (Vatican City State)', 'Honduras', 'Hong Kong', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iran, Islamic Republic of', 'Iraq', 'Ireland', 'Isle of Man', 'Israel', 'Italy', 'Jamaica', 'Japan', 'Jersey', 'Jordan', 'Kazakhstan', 'Kenya', 'Kiribati', "Korea, Democratic People's Republic of", 'Korea, Republic of', 'Kuwait', 'Kyrgyzstan', "Lao People's Democratic Republic", 'Latvia', 'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Macao', 'Macedonia, Republic of', 'Madagascar', 'Malawi', 'Malaysia', 'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Martinique', 'Mauritania', 'Mauritius', 'Mayotte', 'Mexico', 'Micronesia, Federated States of', 'Moldova, Republic of', 'Monaco', 'Mongolia', 'Montenegro', 'Montserrat', 'Morocco', 'Mozambique', 'Myanmar', 'Namibia', 'Nauru', 'Nepal', 'Netherlands', 'New Caledonia', 'New Zealand', 'Nicaragua', 'Niger', 'Nigeria', 'Niue', 'Norfolk Island', 'Northern Mariana Islands', 'Norway', 'Oman', 'Pakistan', 'Palau', 'Palestinian Territory, Occupied', 'Panama', 'Papua New Guinea', 'Paraguay', 'Peru', 'Philippines', 'Pitcairn', 'Poland', 'Portugal', 'Puerto Rico', 'Qatar', 'Réunion', 'Romania', 'Russian Federation', 'Rwanda', 'Saint Barthélemy', 'Saint Helena, Ascension and Tristan da Cunha', 'Saint Kitts and Nevis', 'Saint Lucia', 'Saint Martin (French part)', 'Saint Pierre and Miquelon', 'Saint Vincent and the Grenadines', 'Samoa', 'San Marino', 'Sao Tome and Principe', 'Saudi Arabia', 'Senegal', 'Serbia', 'Seychelles', 'Sierra Leone', 'Singapore', 'Sint Maarten (Dutch part)', 'Slovakia', 'Slovenia', 'Solomon Islands', 'Somalia', 'South Africa', 'South Georgia and the South Sandwich Islands', 'Spain', 'Sri Lanka', 'Sudan', 'Suriname', 'South Sudan', 'Svalbard and Jan Mayen', 'Swaziland', 'Sweden', 'Switzerland', 'Syrian Arab Republic', 'Taiwan, Province of China', 'Tajikistan', 'Tanzania, United Republic of', 'Thailand', 'Timor-Leste', 'Togo', 'Tokelau', 'Tonga', 'Trinidad and Tobago', 'Tunisia', 'Turkey', 'Turkmenistan', 'Turks and Caicos Islands', 'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'United States', 'United States Minor Outlying Islands', 'Uruguay', 'Uzbekistan', 'Vanuatu', 'Venezuela, Bolivarian Republic of', 'Viet Nam', 'Virgin Islands, British', 'Virgin Islands, U.S.', 'Wallis and Futuna', 'Yemen', 'Zambia', 'Zimbabwe'],
            #placeholder="country",
            required=True,
            id='country-value',
            placeholder='Please choose a country',
            ),
            ]),

            html.H2(children='Select keywords', id='select-keywords-title', className='input-title'),
            html.P(''' 
                explanation
            ''', className='input-explanation'),
            #Main div for checklists
            html.Div(id='checklist-master-div', children=[
                dbc.Row(
                [
                    dbc.Col(
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.H4('Man made: '),
                                    #dbc.Checklist(man_made_list, man_made_list, className="root-checklist", id="man-made-checklist",
                                    dbc.Checklist(man_made_list, ['shoot', 'shooting'], className="root-checklist", id="man-made-checklist",
                                        style={
                                            # 'margin' : '23.8% 0',
                                            'margin-bottom' : '132px'
                                        }                                    
                                    ),
                                ]
                            )
                        ),
                    ),
                    dbc.Col(        
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.H4('Natural: '),
                                    #dbc.Checklist(natural_list, natural_list, className="root-checklist", id="natural-checklist",
                                    dbc.Checklist(natural_list, [], className="root-checklist", id="natural-checklist",
                                        style={
                                            'margin-bottom' : '132px'
                                        }
                                    )
                                ]
                            )
                        ),
                    ),
                    dbc.Col(
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.H4('Outcomes: '),
                                    #dbc.Checklist(outcomes_list, outcomes_list, className="root-checklist", id="outcomes-checklist"),
                                    dbc.Checklist(outcomes_list, ['dead', 'injured'], className="root-checklist", id="outcomes-checklist"),
                                ]
                            )
                        ), 
                        width={"order": "last"}
                    ),
                    dbc.Col(      
                        dbc.Card(
                            dbc.CardBody(
                                [
                                    html.H4('RTA: '),
                                    #dbc.Checklist(rta_list, rta_list, className="root-checklist", id="rta-checklist", ),
                                    #dbc.Checklist(rta_list, rta_list, id="rta-checklist", #className="lh-5",
                                    dbc.Checklist(rta_list, [], id="rta-checklist", #className="lh-5",
                                        style={
                                            'margin-bottom' : '106px',
                                            #'float' : 'center'
                                        }
                                    ),
                                ]
                            ),
                        ), 
                    ),
                ],
                
                #justify="center",
                ),
            ]
            ),            

            html.H3('Perform pre-processing? ', className='input-title'),
            html.P(''' 
                    explanation
                ''', className='input-explanation'),
            html.Div(className='switch-master-div', children=[
                dbc.Switch(
                    id="prepro-switch",
                    label="Perform pre-processing",
                    value=True,
                ),
            ]),
            
            html.H3('Perform Classification? ', className='input-title'),
            html.P(''' 
                    explanation
                '''
                , className='input-explanation'),
            html.Div(className='switch-master-div', children=[
                dbc.Switch(
                    id="classification-switch",
                    label="Perfrom classification",
                    value=True,
                ),
            ]),

            html.H3('For what time range would you like to search? ', className='input-title'),
            html.P(''' 
                    explanation
                '''
                , className='input-explanation'),
            
            html.Div(className='slider-master-div', children=[
                dbc.Form(
                    dcc.RangeSlider(1990, 2022, 1, value=[2010, 2020], id="range-slider", 
                        marks={
                            1990: '1990',
                            1995: '1995',
                            2000: '2000',
                            2005: '2005',
                            2010: '2010',
                            2015: '2015',
                            2020: '2020',
                        },
                        tooltip={"placement": "bottom", "always_visible": True}),
                        className="mb-3",
                    ),
                ],
            ),

            dbc.Button(id='submit_button', color="primary", children='Submit variables', n_clicks=0),
            
            dbc.Toast(
                "Please choose atleast one variable and one country",
                id="warning-toast",
                header="Warning",
                is_open=False,
                dismissable=True,
                icon="danger",
                # top: 66 positions the toast below the navbar
                style={"position": "fixed", "top": 66, "right": 10, "width": 400},
            ),
            
            html.Hr(),
            
            #html.Div(id='text-id', children='sample', style={'padding-left':'2%'}),
            
            html.Footer('Created by Ludde Jahrl, with help from Katerina Vrotsou & Kostiantyn Kucher. Based on resarch made by Lotta Velin, Laura Pompermaier & Tina Schmid Neset', style={
                'text-align': 'center',
                'padding-bottom' : '1%',
                'font-size' : '0.7em'
                }
                
            ),
            
            # html.Div(
            #     [
            #         dbc.Progress(value=ddg_procent, color="primary", className="mb-3"),
            #     ]
            # )
        
        ]),
        #----------------------------------------------------SECOND TAB FOR VISULAISATION-----------------------------------------------------
        dbc.Tab(label='Visualising data', children=[
            #https://dash.plotly.com/dash-core-components/upload
            html.H3('Upload file for visualisation (result found in: ...) ', className='input-title'),
            
            html.Div([
                dcc.Upload(
                    id='upload-data',
                    children=html.Div([
                        'Drag and Drop or ',
                        html.A('Select Files', id='select-files-text')
                            ]),
                    #multiple=True
                ),
                
            html.P(''' visualisation coming soon ;) '''),
            
            html.Div(id='output-data-upload'),
            ])  
            
        ]),
        
    ]),
    
])

@app.callback(
    #Output('text-id', 'children'),
    Output("warning-toast", "is_open"),
    [
        Input('submit_button', 'n_clicks'),
    ],
    [
        State('country-value', 'value'),
        State('man-made-checklist', 'value'),
        State('natural-checklist', 'value'),
        State('outcomes-checklist', 'value'),
        State('rta-checklist', 'value'),
        State('prepro-switch', 'value'),
        State('classification-switch', 'value'),
        State('range-slider', 'value'),
        
    ]
    )

def load_variables(button_clicks, country, man_made_vals, natural_vals, outcomes_vals, rta_vals, do_prepro, do_classification, time_range):
    
    if button_clicks > 0:
        
        print('button is pressed') 
        
        parameter_checklist_tot = man_made_vals + natural_vals + outcomes_vals + rta_vals
        
        #check if all variables are choosen
        if len(parameter_checklist_tot) == 0:
            return True
        elif(country is None):
            return True
        
        #create list od years to 
        time_range_list = list(range(time_range[0], time_range[1]+1, 1))
        
        [csv_res, statistics_path] = duckduckgo_build_url_list(country, man_made_vals, natural_vals, outcomes_vals, rta_vals, time_range_list)
        
        if do_prepro:
            print('prepro')
            [duplicates_removed_path, statistics_path] = drop_duplicates_url_title(csv_res, statistics_path)
            [unwanted_removed_path, statistics_path] = drop_unwanted_sites(duplicates_removed_path, statistics_path)
            [keyword_conf_path, statistics_path] = confirm_keywords(unwanted_removed_path, statistics_path, country, man_made_vals, natural_vals, outcomes_vals, rta_vals)
            [retrived_articles, statistics_path] = retriever(keyword_conf_path, statistics_path)
            [outfile, statistics_path] = drop_short_art(retrived_articles, statistics_path)
            #add remove similair

            if country == 'Rwanda':
                print('Drop region based...TODO')
                #drop_region()

        else:
            [outfile, statistics_path] = retriever(csv_res, statistics_path)

        if do_classification:
            print('classfication')
            [classfied_lr, statistics_path] = classifier_lr(outfile, statistics_path)
       
            [outfile, statistics_path] = classifier_bert(classfied_lr, statistics_path)

        # if ner
        print('Do NER')
        
        print('return DONE')
        
        return 'Country: {} Parametres: {}'.format(country, parameter_checklist_tot)
    
def parse_contents(contents, filename, date):
    content_type, content_string = contents.split(',')

    decoded = base64.b64decode(content_string)
    try:
        if 'csv' in filename:
            # Assume that the user uploaded a CSV file
            df = pd.read_csv(
                io.StringIO(decoded.decode('utf-8')))
        elif 'xls' in filename:
            # Assume that the user uploaded an excel file
            df = pd.read_excel(io.BytesIO(decoded))
    except Exception as e:
        print(e)
        return html.Div([
            'There was an error processing this file.'
        ])

    return html.Div([
        html.H5(filename),
        html.H6(dt.fromtimestamp(date)),

        dash_table.DataTable(
            df.to_dict('records'),
            [{'name': i, 'id': i} for i in df.columns]
        ),

        html.Hr(),  # horizontal line
    ])

#calllback for data upload and content parser
@app.callback(
    Output('output-data-upload', 'children'),
    Input('upload-data', 'contents'),
    State('upload-data', 'filename'),
    State('upload-data', 'last_modified'))

def update_output(list_of_contents, list_of_names, list_of_dates):
    if list_of_contents is not None:
        children = [
            parse_contents(c, n, d) for c, n, d in
            zip(list_of_contents, list_of_names, list_of_dates)]
        return children

if __name__ == '__main__':
    app.run_server(debug=True)
            
        


