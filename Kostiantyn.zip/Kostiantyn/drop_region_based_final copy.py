import pandas as pd
import csv
import time

#https://datahub.io/core/world-cities

#not modified for new format!

place_names = [
    "Rwanda",
    "Kidaho",
    "Muvumba",
    "Lubirizi",
    "Nyagatare",
    "Rwandan capital",
    "Rwemhasha",
    "Capital of Rwanda",
    "Mulindi",
    "Kirambo",
    "Kigali",
    "Byumba",
    "Muhanga",
    "Gatunda",
    "Gisenyi",
    "Ngarama",
    "Kibuye",
    "Rwamagana",
    "Cyangugu",
    "Cyamba",
    "Gabiro",
    "Ruhengeri",
    "Nyanza",
    "Kora",
    "Mutura",
    "Bugarama",
    "Gikongoro",
    "Nyamata",
    "Nyagatare",
    "Busogo",
    "Rubengera",
    "Ruhango",
    "Kayonza",
    "Butare",
    "Kabuga",
    "Musanze",
    "Munini",
    "Ndera",
    "Murambi",
    "Gisagara",
    "Ngororero",
    "Kabarore",
    "Kagitumba",
    "Rusumo",
    "Cyanika"
    "Gatuna",
    "Kibeho",
    "Goma",
    "Nemba",
    "Northern Province",
    "Northern District",
    "Southern Province",
    "Southern District",
    "Eastern Province", 
    "Eastern District", 
    "Western Province",
    "Western District",
    "Kagali",
    "Kinihira",
    "Gisenya",
    "Nyundo",
    "Muhura",
    "Rushashi",
    "Rutare",
    "Ngaru",
    "Mbogo",
    "Murambi",
    "Rukara",
    "Shyorongi",
    "Kiyumba",
    "Kinyinya",
    "Gikoro",
    "Runda",
    "Kicukiro",
    "Bulinga",
    "Bicumbi",
    "Butamwa",
    "Mabanza",
    "Gitarama",
    "Kigarama",
    "Birambo",
    "Bugesera",
    "Gishyita",
    "Bwakira",
    "Rukira",
    "Kibungo",
    "Rilima",
    "Rwamatamu",
    "Masango",
    "Ruhango",
    "Gashora",
    "Sake",
    "Gatagara",
    "Kirehe",
    "Bare",
    "Ngenda",
    "Kaduha",
    "Nyabisindu",
    "Rwesero",
    "Karaba",
    "Rusatira",
    "Gisakura",
    "Kamembe",
    "Karama",
    "Rwumba",
    "Kitabi",
    "Cyimbogo",
    "Karengera",
    "Nyakabuye",
    "Bugumya",
    "Ruramba",
    "Busoro",
    "Runyombyi",
    "Nzega"
    ]

def drop_region(data):

    file_out = data[:len(data)-4] + '_region_checked.csv'

    df_file = pd.read_csv(data) 

    df_file_len_prior = len(df_file)
    
    df_file['region_mentioned'] = False

    print("\nRemoving rows were article text doesn't mention atleast ONE of the regions in list...")

    i = 0

    for index, row in df_file.iterrows():
        word_found = False
        
        for place in place_names:
            
            article_text = str(row['article_text'])
            
            if place in article_text:
                
                df_file.at[i,'region_mentioned'] = True 
                
                word_found = True
            
            if word_found == True:
                break
        
        i+=1

    df_file = df_file.drop(df_file[df_file['region_mentioned'] != True].index)

    print('\nRows dropped: ' + str(df_file_len_prior - len(df_file)) + ' | Total number of articles: ' + str(len(df_file)) + '\n')

    #remove regin_mentioned colomn
    #df_file.drop('region_mentioned', inplace=True, axis=1)

    df_file.to_csv(file_out, index=False)

    print('Dropped based on region DONE')

    return(file_out)

        
        