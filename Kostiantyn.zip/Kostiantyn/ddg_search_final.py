#Imports
import pandas as pd
import math
import json
import csv
from distutils import config
from duckduckgo_search import ddg
from duckduckgo_search import ddg_news
import time
from datetime import datetime as dt
from datetime import date as dt_date # named such as to not mess with conflicting name 'date' for ddg api
import random

#-----------------------------------------------DEFAULT SEARCH SETTINGS FOR QUERY------------------------------------------------------------
rta_list_prefix = 'accident'

# search refinement by appending common sites  
common_sites = [
    "reuters.com/",
    "english.news.cn/",
    "bbc.com/"
    ]

# search refinement by excluding common sites  
exclude_sites = [
    "wikipedia.org/",
    "cdc.gov/",
    "featureshoot.com/"
    ]

#-----------------------------------------------/DEFAULT SEARCH SETTINGS FOR QUERY------------------------------------------------------------------------

def duckduckgo_build_url_list(country: str, man_made_vals: list[str], natural_vals: list[str], outcomes_vals: list[str], rta_vals: list[str], years_list: list[str]):

    if not __name__ == "__main__":
        exit

    if (country is None) or (man_made_vals or natural_vals or outcomes_vals or rta_vals) == 0:
        print('No parameters given')
        exit

    ct = dt.now()

    #-----------------------------------------------LIST OF RWANDAN NEWSITES FOUND ONLINE-------------------------------------------------------------
    sites_list_rwanda_eng = [
    "", #empty to include search for non site specifik searches
    "newtimes.co.rw/",
    "umuryango.rw/eng/",
    "ktpress.rw/",
    "rwandatoday.africa/",
    "therwandan.com/",
    "eng.inyarwanda.com/",
    "en.igihe.com/",
    "jambonews.net/en/"
    ]
    #-----------------------------------------------/LIST OF RWANDAN NEWSITES FOUND ONLINE------------------------------------------------------------

    #-----------------------------------------------CREATE FULL LIST OF SEARCH QUERYS-----------------------------------------------------------------
    #site_suffix = "site:"

    # Full list of individual search querrys
    full_list = []
    
    #list of querys for (man made) keywords and outcomes
    if not len(man_made_vals) == 0:
        for i, words in enumerate(man_made_vals):
            for j, words in enumerate(outcomes_vals):
                full_list.append('"' + country + '" "' + man_made_vals[i] + '" ' + '"' + outcomes_vals[j] + '"')
    #list of querys for (natural) keywords and outcomes  
    if not len(natural_vals) == 0:
        for i, words in enumerate(natural_vals):
            for j, words in enumerate(outcomes_vals):
                full_list.append('"' + country + '" "' + natural_vals[i] + '" ' + '"' + outcomes_vals[j] + '"')
    #list of querys for (rta) keywords and outcomes     
    if not len(rta_vals) == 0:
        for i, words in enumerate(rta_vals):
            for j, words in enumerate(outcomes_vals):
                full_list.append('"' + country + '" "' + rta_list_prefix + '" "' + rta_vals[i] + '"' + ' "' + outcomes_vals[j] + '"')
                
    #shuffle list to not prompt scraping issues later
    random.shuffle(full_list)

    #create session name
    now = dt.now()
    current_time = now.strftime("%H_%M_%S")
    today = dt_date.today()
    current_day = today.strftime("%d_%m_%Y")
    
    csv_name = './systematic_media_review_v3/source/data/duckduckgo_results/{}_{}_{}.csv'.format(country, current_day, current_time) #systematic_media_review_v3/source/data/duckduckgo_results

    print("\nBuilding List of Duck Duck Go search API results... (Results found in: '" + str(csv_name) + "')\n")  

    #-----------------------------------------------/CREATE FULL LIST OF SEARCH QUERYS----------------------------------------------------------------

    #-----------------------------------------------CALLING DUCK DUCK GO SEARCH API-------------------------------------------------------------------

    # STATISTICS FOR THE API CALL
    #Counter to check if the maximum amount of results were achieved, meaning possible loss
    reached_max_results_ddg = 0
    reached_max_results_ddg_news = 0
    
    #counter to check if the query
    no_hits_found_ddg = 0;
    no_hits_found_ddg_news = 0;

    #API call progress
    searches_made = 0

    #Total number of hits & hits after dupes removal
    total_number_of_hits = 0

    #start measuring time for api calls
    start_time = time.time()
    
    # print('Please name the file (Finish with 0): ')
    # file_val = input('Name: ')
    
    results_header = ['title', 'body', 'date', 'source', 'url']
    #title,body,date,source,url

    #for removing , as to not mess with format of csv (comma seperated ...) file
    removal_char = ","
    
    # 1. Open a new CSV file
    with open(csv_name, 'w+', encoding="UTF8") as file:
        
        # 2. Create a CSV writer
        writer = csv.writer(file)

        # 3. Write data to the file
        writer.writerow(results_header)
        
        for keyword in full_list:
            
            keywords = keyword
            
            r = ddg(keywords, region='wt-wt', safesearch='Off', max_results=200)
            p = ddg_news(keywords, region='wt-wt', safesearch='Off', max_results=240)   
            
            time.sleep(1)
            
            try:
                for x, items in enumerate(r):
                    
                    title = r[x]['title']
                    title = title.replace(removal_char, " ")
                    body = None
                    source = None
                    date = None
                    url = r[x]['href']
                    
                    writer.writerow([title, body, source, date, url])

                    #Maximum amount of hits found for query (ddg)
                    if x == 200:
                        reached_max_results_ddg += 1
                    
                    len_r = len(r)
            except:
                #No hits found
                no_hits_found_ddg += 1
                len_r = 0
                pass
            
            try:
                for y, items in enumerate(p):
                    
                    title = p[y]['title']
                    title = title.replace(removal_char, " ")
                    source = p[y]['source']
                    source = source.replace(removal_char, " ")
                    date = p[y]['date']
                    date = date.replace(removal_char, " ")
                    body = p[y]['body']
                    body = body.replace(removal_char, " ")
                    url =  p[y]['url']
                    
                    writer.writerow([title, body, date, source, url])
                    
                    #Maximum amount of hits found for query (ddg)
                    if x == 240:
                        reached_max_results_ddg += 1
                    
                    len_p = len(p)
            except:
                #No hits found
                no_hits_found_ddg_news += 1
                len_p = 0
                pass
            
            #total_number_of_hits += (len_p + len_r)
            total_number_of_hits += (len_r+len_p)
            
            searches_made +=1
            
            #progress indicator (needs to be one line to be able to read stream correctly on mac ('\r' issue), add \n to windows machine?)
            print('Progress: ' + str(searches_made) + '/' + str(len(full_list)) + ' (' + str(round((searches_made/(len(full_list))) * 100, 2)) + ' %)' + ' | Tot. hits: ' + str(total_number_of_hits) + ' | No results found: ' + str(no_hits_found_ddg + no_hits_found_ddg_news)  + ' | Executed: ' + str(ct), end='\r')    
            
    #-----------------------------------------------/CALLING DUCK DUCK GO SEARCH API------------------------------------------------------------------

    #-----------------------------------------------SEARCH STATISTICS---------------------------------------------------------------------------------
    print('\n\n\nFINAL SEARCH STATISTICS:')
    print('Total number of search terms:                  ' + str(len(full_list)))
    print('Total number of API calls:                     ' + str(len(full_list)*2))

    print('Total number of hits:                          ' + str(total_number_of_hits))
    print('Average hits per search:                       ' + str(round(total_number_of_hits/len(full_list),2)))

    print('Reached maximum results (ddg):                 ' + str(reached_max_results_ddg))
    print('Reached maximum results (ddg_news):            ' + str(reached_max_results_ddg_news))

    print('No results (ddg):                              ' + str(no_hits_found_ddg))
    print('No results (ddg_news):                         ' + str(no_hits_found_ddg_news))
    print('Total searches with no results:                ' + str(no_hits_found_ddg_news+no_hits_found_ddg))

    time_elapsed = time.time() - start_time

    print('API call time:                                 ' + '%s seconds' % (time_elapsed))

    print("\nddg_search_v1: DONE")
    
    #add relevant data at the end in a dict? json?
    #full list of keywords
    #api call information
    #tiemelapsed
    
    statistics = {
        'ddg ' : 'ddg_res_{}_{}_{}.csv'.format(country, current_day, current_time),
        'man_made_variables' : man_made_vals,
        'natural_variables' : natural_vals,
        'rta_variables' : rta_vals,
        'outcomes_variables' : outcomes_vals,
        'Total number of search terms' : len(full_list),
        'Total number of API calls' : len(full_list)*2,
        'Total number of hits' : total_number_of_hits,
        'Average hits per search' : round(total_number_of_hits/len(full_list),2),
        'Reached maximum results (ddg)' : reached_max_results_ddg,
        'Reached maximum results (ddg_news)' : reached_max_results_ddg_news,
        'No results (ddg)' : no_hits_found_ddg,
        'No results (ddg_news)' : no_hits_found_ddg_news,
        'Total searches with no results' : no_hits_found_ddg_news+no_hits_found_ddg,
        'API call time' : time_elapsed,
        'length after duplicats dropped (url)' : None,
        'length after removing unwanted sites' : None,
        'length after keyword confirmation' : None,
        'length after duplicats dropped (title)' : None,
        'length after download' : None,
        'failed to download' : None,
        'length after short dropped' : None,
        'length after region confirmation' : None,
        'classified relevant (BERT)' : None,
        'classified not relevant (BERT)' : None,
        'classified relevant (logistic regression)' : None,
        'classified not relevant (logistic regression)' : None,
        'ner data' : None
    }
    
    stats_path = "./systematic_media_review_v3/source/data/statistics/stats_{}_{}_{}.json".format(country, current_day, current_time)
    
    with open(stats_path, "w") as write_file:
        json.dump(statistics, write_file, indent=4)
        
    print('Creating query list DONE')
    
    return(csv_name, stats_path)
#----------------------------------------------------------------------------------------------------------/DDG----------------------------------------------------------------------------------------------------