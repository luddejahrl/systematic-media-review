sites_names = [
    'wikipedia.org',
    'twitter.com',
    'cdc.gov/',
    'featureshoot.com/',
    'gettyimages.com/'
    ]

def drop_unwanted_sites(infile: str, statistics_path: str): 

    if not __name__ == "__main__":
        exit

    import csv
    import pandas as pd
    import json

    #file given to the function
    df_file = pd.read_excel(infile) 

    old_len = len(df_file)
    
    #add colomn for condition
    df_file['condition'] = False

    for i in range(1,len(df_file)-1):
        url = df_file.loc[i]['url']
        
        for sites in sites_names:
            if sites in url:
                df_file.at[i,'condition'] = True 
    
    df_file = df_file.drop(df_file[df_file['condition'] == True].index)

    rows_removed = old_len - len(df_file)

    print('\nRows removed: ' + str(rows_removed))

    #remove regin_mentioned colomn
    df_file = df_file.drop('condition', axis=1)

    #adding statistics
    with open(statistics_path) as json_file:
        json_decoded = json.load(json_file)
    json_decoded['length after removing unwanted sites'] = (len(df_file))
    with open(statistics_path, 'w') as json_file:
        json.dump(json_decoded, json_file, indent=4)
    
    #set path for new out_file that contains atleast one of the keywords
    new_out_file = infile[:len(infile)-5] + '_sr.xlsx'

    #save results after keyword confirmation to a new excel file
    df_file.to_excel(new_out_file, index=False)

    print("\nRemoving rows with urls containing unwanted sites from API search results... (Results found in; {}".format(new_out_file))

    print('\nRemoving unwanted sites DONE\n')
    
    return(new_out_file, statistics_path)
